package mineshafter.cache;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SkinsCacheRequest extends java.net.CacheRequest {

    final ByteArrayOutputStream body = new ByteArrayOutputStream();

    @Override
    public OutputStream getBody() throws IOException {
        return body;
    }

    @Override
    public void abort() {
        
    }
}
