package mineshafter;

import java.applet.Applet;
import java.awt.Frame;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Map;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import mineshafter.proxy.MineProxy;
import mineshafter.util.Resources;
import mineshafter.util.SimpleRequest;
import mineshafter.util.Streams;
import mineshafter.util.SplashScreen;

public class MineClient extends Applet {

    private static final long serialVersionUID = 1L;
    protected static float VERSION = 2.8f;
    protected static int proxyPort = 8061;
    protected static int proxyHTTPPort = 8062;
    protected static int proxyHTTPSPort = 8063;
    protected static String launcherDownloadURL = "https://s3.amazonaws.com/MinecraftDownload/launcher/minecraft.jar";//"http://www.minecraft.net/download/minecraft.jar";
    protected static String normalLauncherFilename = "Minecraft.jar";
    protected static String hackedLauncherFilename = "Minecraft_modified.jar";
    protected static boolean portableMode = false;
    public static String authServer = Resources.loadString("auth").trim();
    private static SplashScreen splash;
    final static int MAXPROGRESS = 100;
    final static int PROGRESS_STEPS = 11;
    final static int PROGRESS_INCREMENT = MAXPROGRESS/PROGRESS_STEPS;
    static int progress = 0;
    static boolean launcherModified = false;
    static String gamePath;
    
    @Override
    public void init() {
        MineClient.main(new String[0]);
    }

    public static void main(String[] args) {
        splashScreenInit();
        try {
            /* Get Update Info */
            progress += PROGRESS_INCREMENT;
            splash.setProgress("Checking for updates", progress);
            String buildNumber = getGameBuildNumber();
            
            String updateInfo = new String(SimpleRequest.get("http://" + authServer + "/update.php?name=client&build=" + buildNumber));

            String[] updateInfoArray = updateInfo.split(":");

            String verstring = updateInfoArray[0];
            boolean needGameUpdate = Boolean.parseBoolean(updateInfoArray[1]);
            String gameVersion = updateInfoArray[2];
            
            progress += PROGRESS_INCREMENT;
            splash.setProgress(progress);
            /* Check for new client version */
            /* Default to 0 */
            if (verstring.isEmpty()) {
                verstring = "0";
            }

            float version;
            try {
                version = Float.parseFloat(verstring);
            } catch (Exception e) {
                version = 0;
            }

            /* Print Verions to console */
            System.out.println("Current proxy version: " + VERSION);
            System.out.println("Gotten proxy version: " + version);
            
            if (VERSION < version) {
                JOptionPane.showMessageDialog(null, "A new version of Mineshafter is available at http://" + authServer + "/\nGo get it.", "Update Available", JOptionPane.PLAIN_MESSAGE);
                System.exit(0);
            }

            /* Check for new game version */
            System.out.println("Game Version Found: " + buildNumber);
            System.out.println("Needs Update: " + needGameUpdate);
            System.out.println("Latest Version: " + gameVersion);
            if (needGameUpdate) {
                int answer = JOptionPane.showConfirmDialog(null, "A new version of Minecraft is available, would you like to update to version " + gameVersion + "?",
                        "Game Update Found!", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
                if (answer == JOptionPane.YES_OPTION) {
                    int areYouSure = JOptionPane.showConfirmDialog(null, "Make sure any online servers you would like to play on are updated"
                            + " to version " + gameVersion + " or else you will not be able to play on them until they do.",
                            "Are you sure?", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    if (areYouSure == JOptionPane.YES_OPTION) {
                            rDelete(new File(gamePath));
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error while updating:");
            System.out.println(e);
            System.exit(1);
        }
        
        progress += PROGRESS_INCREMENT;
        splash.setProgress("Checking start options", progress);
        
        try {
            String auth = null;
            for (String arg : args) {
                if (arg.startsWith("-")) {
                    if (arg.equalsIgnoreCase("-p") || arg.equalsIgnoreCase("--portable")) {
                        portableMode = true;
                    }
                } else {
                    auth = arg;
                }
            }

            progress += PROGRESS_INCREMENT;
            splash.setProgress("Starting Proxy", progress);
            /* Start the Proxy */
            MineProxy.listen(proxyPort, proxyHTTPPort, proxyHTTPSPort, VERSION, auth);
            
            /* Start the Launcher */
            progress += PROGRESS_INCREMENT;
            splash.setProgress("Starting Launcher", progress);
            startLauncher();

            System.setProperty("http.proxyHost", "127.0.0.1");
            System.setProperty("http.proxyPort", Integer.toString(proxyPort));
            System.setProperty("https.proxyHost", "127.0.0.1");
            System.setProperty("https.proxyPort", Integer.toString(proxyPort));

        } catch (Exception e) {
            System.out.println("Something bad happened:");
            System.exit(1);
        }
    }
    
    private static void rDelete(File root){
        if(root.isDirectory()){
            for(File file : root.listFiles()){
                rDelete(file);
            }
            root.delete();
        } else {
            root.delete();
        }
    }

    private static void splashScreenInit() {
        ImageIcon myImage = new ImageIcon(MineClient.class.getResource("splashimg.png"));
        splash = new SplashScreen(myImage);
        splash.setLocationRelativeTo(null);
        splash.setProgressMax(MAXPROGRESS);
        splash.setProgress("Loading...", progress);
        splash.setScreenVisible(true);
    }
    
    private static void splashScreenDestruct() {
        splash.setScreenVisible(false);
        splash = null;
    }
    
    private static String getGameBuildNumber() {
        // set variables based on OS
        String versionPath = null;
        
        String os = System.getProperty("os.name").toLowerCase();
        Map<String, String> enviornment = System.getenv();
        
        if (os.contains("windows")) {
            versionPath = enviornment.get("APPDATA") + "\\.minecraft\\bin\\version";
            gamePath = enviornment.get("APPDATA") + "\\.minecraft\\bin";
        } else if (os.contains("mac")) {
            versionPath = "/Users/" + enviornment.get("USER") + "/Library/Application Support/minecraft/bin/version";
            gamePath = "/Users/" + enviornment.get("USER") + "/Library/Application Support/minecraft/bin";
        } else if(os.contains("linux")){
            versionPath = enviornment.get("HOME") + "/.minecraft/bin/version";
            gamePath = enviornment.get("HOME") + "/.minecraft/bin";
        }

        // get current game version number
        if(new File(versionPath).exists()){
            return Resources.loadString(versionPath).trim();
        } else {
            return "0";
        }
    }

    /* Look into better documenting what this code does */
    public static void startLauncher() {
        try {
            progress += PROGRESS_INCREMENT;
            splash.setProgress("hack launcher", progress);
            /* Ig the hacked game exists */
            if (new File(hackedLauncherFilename).exists() && launcherModified == true) {
                URL u = new File(hackedLauncherFilename).toURI().toURL();
                URLClassLoader cl = new URLClassLoader(new URL[]{u});
                @SuppressWarnings("unchecked")
                Class<Frame> launcherFrame = (Class<Frame>) cl.loadClass("net.minecraft.LauncherFrame");
                Class<?> utilClass = cl.loadClass("net.minecraft.Util");
                Field portable = utilClass.getDeclaredField("portable");
                portable.setBoolean(null, portableMode);
                Method main = launcherFrame.getMethod("main", new Class[]{String[].class});
                
                progress += PROGRESS_INCREMENT;
                splash.setProgress("Starting Launcher", progress);
                main.invoke(launcherFrame, new Object[]{new String[0]});
                
                progress += PROGRESS_INCREMENT;
                splash.setProgress("Don't Login Yet!", progress);
                splash.setAlwaysOnTop(true);
                Thread.sleep(3500);
                progress = MAXPROGRESS;
                splash.setProgress("Okay, Now Login", progress);
                Thread.sleep(500);
                splashScreenDestruct();
                
            }
            /* If the normal game exists */ 
            else if (new File(hackedLauncherFilename).exists()){
                progress += PROGRESS_INCREMENT;
                splash.setProgress(progress);
                new File(hackedLauncherFilename).delete();
                editLauncher();
                launcherModified = true;
                startLauncher();
            }
            /* If the normal game exists */ 
            else if (new File(normalLauncherFilename).exists()) {
                progress += PROGRESS_INCREMENT;
                splash.setProgress(progress);
                editLauncher();
                startLauncher();
            }
            /* if no minecraft game exists */ else {
                progress += PROGRESS_INCREMENT;
                splash.setProgress(progress);
                try {
                    InputStream in = new URL(launcherDownloadURL).openStream();
                    OutputStream out = new FileOutputStream(normalLauncherFilename);
                    Streams.pipeStreams(in, out);
                    in.close();
                    out.close();
                    editLauncher();
                    startLauncher();
                } catch (Exception ex) {
                    System.out.println("Error downloading launcher:");
                    return;
                }
            }
        } catch (Exception e1) {
            System.out.println("Error starting launcher:");
        }
    }

    public static void editLauncher() {
        try {
            ZipInputStream in = new ZipInputStream(new FileInputStream(normalLauncherFilename));
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(hackedLauncherFilename));
            ZipEntry entry;
            String n;
            InputStream dataSource;
            while ((entry = in.getNextEntry()) != null) {

                n = entry.getName();

                if (n.contains(".svn") || n.equals("META-INF/MOJANG_C.SF") || n.equals("META-INF/MOJANG_C.DSA") || n.equals("net/minecraft/minecraft.key") || n.equals("net/minecraft/Util$OS.class")) {
                    continue;
                }

                out.putNextEntry(entry);

                if (n.equals("META-INF/MANIFEST.MF")) {
                    dataSource = Resources.load("manifest.txt");
                } else if (n.equals("net/minecraft/Util.class")) {
                    dataSource = Resources.load("Util.class");
                } else {
                    dataSource = in;
                }

                Streams.pipeStreams(dataSource, out);
                out.flush();
            }
            
            in.close();
            out.close();
        } catch (Exception e) {
            System.out.println("Editing launcher failed:");
        }
    }
}